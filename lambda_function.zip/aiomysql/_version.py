try:
    from ._scm_version import version
except ImportError:
    version = "unknown"
